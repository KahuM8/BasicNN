For using the XMLManager class you need to download Xerces:
http://xerces.apache.org/xerces-j/

Put the xercesImpl.jar into this directory and add it to
your class path.